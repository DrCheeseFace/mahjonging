# Riichi Mahjong > 2023-12-27 9:35pm
https://universe.roboflow.com/hust-xq5rx/riichi-mahjong

Provided by a Roboflow user
License: CC BY 4.0

